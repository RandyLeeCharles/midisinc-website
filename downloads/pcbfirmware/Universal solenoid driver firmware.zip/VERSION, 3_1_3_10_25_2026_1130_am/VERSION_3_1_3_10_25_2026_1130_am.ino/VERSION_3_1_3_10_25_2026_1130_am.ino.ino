// MSD PROGRAMABLE FIRMWARE, STABLE
// Includes: MIDI, EEPROM, LCD, Sustain/Pulse/Timed modes
// VERSION, 3.1.3 10_25_2026_1130_am
//TESTING SETTINGS: IN SERIAL MONITOR PUT EACH ONE OF THESE IN INDIVIDUALLY PRESS ENTER, TYPE IN SAVE, PRESS ENTER
// CONTINUE UNTIL THE ABOVE HAS BEEN DONE FOR EACH SETTING
// CLEAR SERIAL MONITOR
//TYPE IN READ, HIT ENTER TO VERIFY SETTINGS HAVE BEEN SAVED

//OUTPUT = THE NUMBER OF THE OUTPUT YOU ARE PROGRAMING,
// NOTE: THE NOTE NUMBER YOU ARE ASSIGNING TO THE OUTPUT
// CHANNEL: THE CHANNEL NUMBER ASSOCIATED WITH THE NOTE OUTPUT IN THE MIDI FILE CAN BE USED TO FOR ASSIGN A PIPE TO A CERTAIN RANK.
// ON/OFF: THE ON/OFF CONNECTION ON THE MSD YOU ARE USING TO ACTIVATE OR DEACTIVATE THIS OUPUT/NOTE. THERE ARE 12 AVAILABLE ON/OFF INPUTS
// MODE: THE STYLE OF PLAY YOU WANT ON THE PIPE, SUSTAIN (WHICH IS THE NORMAL MODE),, TIMED;(USED FOR SOMETING LIKE A STIRKE ON A SNARE DRUM), MOMENTARY;(OFTEN USED ON A GLOCK OR XYLOPHONE WHERE YOU WNAT IT HIT QUICK AND THEN OFF)
// TIME: THE DURATION THAT THE OUTPUT IS ON (ACTIVE) IN MILISECONDS.

//          C
//    O     H  O
//    U     A  N
//    T  N  N  /  M  T
//    P  O  N  O  O  I
//    U  T  E  F  D  M
//    T  E  L  F  E  E
//    #  #  #  #  #  #
//SET,1,48, 1, 4, 0, 0 NO SPACES BETWEEN CALLS, SPACES IN THIS FOR CLARITY OF WHAT THE CODE STANDS FOR


//SET,2,60,2,4,0,0
//SET,3,72,4,4,0,0
//SET,4,64,7,4,0,0
//SET,5,71,9,4,0,0
//SAVE

#include <EEPROM.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

//#define FW_VERSION "VERSION, 3.1.2 10_01_2026"
#define FW_VERSION "VERSION, 3.1.3 10_25_2026_11:30_am"
#define BOARD_TYPE "MSD12,MSD24,MSD36,MSD48"
#define EEPROM_SIGNATURE 0x4D5344UL
#define CONFIG_VERSION 1
#define ORGAN_MODE_PIN A0
#define DIP1_PIN 30
#define DIP2_PIN 31
#define NUM_OUTPUTS 48
#define NUM_ONOFF 13  //CHANGED FROM 13 TO 14 TRYING TO GET ACTIVATION PINS WORKING CORRECTLY
#define MODE_SUSTAIN 0
#define MODE_PULSE 1
#define MODE_TIMED 2



//!!!!!!!!!!!!!!!!!!!!!!!!!!!!=========================================================================
//change lcd to match the i2c of your lcd!!!!!!!!!!!!!!!!!!!!!!!
LiquidCrystal_I2C lcd(0x27, 20, 4);  //most common address
//LiquidCrystal_I2C lcd(0x25,20,4);
//!!!!!!!!!!!!!!!!!!!!!!!!!!!!=========================================================================





const byte outputPins[NUM_OUTPUTS] = { 3, 2, 5, 4, 7, 6, 9, 8, 11, 10, 13, 12, 15, 14, 17, 16, 29, 28, 27, 26, 25, 24, 22, 23, A14, A15, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53 };



const byte onOffPins[NUM_ONOFF] = { A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13 };  // pins for new programable driver




struct OutputAssignment {
  byte note;
  byte channel;
  byte onOff;
  byte mode;
  uint16_t timeMs;
};
struct BoardConfig {
  uint32_t signature;
  uint16_t configVersion;
  uint16_t boardID;
  char boardName[20];
  char comment[40];
  OutputAssignment outputs[NUM_OUTPUTS];
};

BoardConfig config;

bool stopFlash = false;
bool lastOrganMode = true;
bool midiPlaying = false;
String boardType = "UNKNOWN";
int boardOutputs = 48;
unsigned long lastMidiActivity = 0;
unsigned long outputOffTime[NUM_OUTPUTS];
//=========================================================
bool timedActive[NUM_OUTPUTS];
bool noteHeld[NUM_OUTPUTS];
bool pulseState[NUM_OUTPUTS];
unsigned long pulseToggleTime[NUM_OUTPUTS];
//==========================================================
unsigned long lcdReturnTime = 0;
//bool organMode();

void detectBoardType() {
  bool sw1 = (digitalRead(DIP1_PIN) == LOW);
  bool sw2 = (digitalRead(DIP2_PIN) == LOW);

  if (!sw1 && !sw2) {
    boardType = "MSD12";
    boardOutputs = 12;
  } else if (sw1 && !sw2) {
    boardType = "MSD24";
    boardOutputs = 24;
  } else if (!sw1 && sw2) {
    boardType = "MSD36";
    boardOutputs = 36;
  } else {
    boardType = "MSD48";
    boardOutputs = 48;
  }
}


void loadDefaults() {
  config.signature = EEPROM_SIGNATURE;
  config.configVersion = CONFIG_VERSION;
  config.boardID = 1;
  strcpy(config.boardName, "NEW MSD");
  strcpy(config.comment, "UNCONFIGURED");
  //============================================================
  //for (int i = 0; i < NUM_OUTPUTS; i++) {
  //=================================================
  for (int i = 0; i < boardOutputs; i++) {
    //============================================
    config.outputs[i].note = 60 + i;
  config.outputs[i].channel = 1;
  config.outputs[i].onOff = 1;
  config.outputs[i].mode = MODE_SUSTAIN;
  config.outputs[i].timeMs = 0;
}
}
void saveConfig() {
  EEPROM.put(0, config);
}
void loadConfig() {
  EEPROM.get(0, config);
  if (config.signature != EEPROM_SIGNATURE || config.configVersion != CONFIG_VERSION) {
    loadDefaults();
    saveConfig();
  }
}

String noteName(byte note) {
  const char* n[] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
  int oct = (note / 12) - 1;
  return String(n[note % 12]) + String(oct);
}


//?????????????????????????????????????????????????????????????????????
void showTestLine(String msg) {
  lcd.setCursor(0, 3);
  lcd.print(" ");

  lcd.setCursor(0, 3);

  if (msg.length() > 0) {
    lcd.print(msg);
  }
}
//?????????????????????????????????????????????????????????????????????
void showIdle() {
  lcd.clear();
  lcd.setCursor((20 - 18) / 2, 0);
  lcd.print("MIDISINC DRIVER");

  //???????????????????????????????????????????????????????????????????????????????
  String line1 = boardType + " ID:" + String(config.boardID);

  lcd.setCursor((20 - line1.length()) / 2, 1);
  lcd.print(line1);
  //????????????????????????????????????????????????????????????????????????????????????

  lcd.setCursor(5, 2);

  if (organMode()) {

    lcd.print("ORGAN MODE");
  } else {
    lcd.print("READY");
  }
}

void showPlaying() {
  lcd.clear();

  lcd.setCursor((20 - 14) / 2, 0);
  lcd.print("MIDISINC DRIVER");

  String line1 =
    boardType + " ID:" + String(config.boardID);

  lcd.setCursor((20 - line1.length()) / 2, 1);
  lcd.print(line1);

  lcd.setCursor((20 - 7) / 2, 2);
  lcd.print("PLAYING");
}

void showEvent(const char* state, byte note, byte ch, byte out, byte mode, uint16_t tm) {
  lcd.clear();
  lcd.setCursor((20 - 18) / 2, 0);
  lcd.print("MIDI MASTER DRIVER");
  String l2 = String(config.boardName) + " ID:" + String(config.boardID);
  lcd.setCursor(max(0, (20 - (int)l2.length()) / 2), 1);
  lcd.print(l2);
  String l3 = String(state) + " " + noteName(note) + "(" + String(note) + ") CH:" + String(ch);
  lcd.setCursor(max(0, (20 - (int)l3.length()) / 2), 2);
  lcd.print(l3);
  String m = (mode == 0) ? "SUSTAIN" : ((mode == 1) ? "PLS" : "TIM");
  String l4 = "OUT:" + String(out + 1) + " " + m;
  if (mode) l4 += " " + String(tm) + "ms";
  lcd.setCursor(max(0, (20 - (int)l4.length()) / 2), 3);
  lcd.print(l4);
  lcdReturnTime = millis() + 1000;
}

bool onOffActive(byte n) {
  if (n < 1 || n > NUM_ONOFF) return false;
  return digitalRead(onOffPins[n - 1]) == LOW;
}
bool organMode() {
  return digitalRead(ORGAN_MODE_PIN) == LOW;
}



void noteOn(byte note, byte ch) {

  //Serial.print("NOTE="); //DEBUG
  //Serial.print(note);//DEBUG
  //Serial.print(" CH=");//DEBUG
  //Serial.println(ch);//DEBUG



  //for (int i = 0; i < NUM_OUTPUTS; i++) {
  for (int i = 0; i < boardOutputs; i++) {
    auto& o = config.outputs[i];

    if (o.note == note && (organMode() || o.channel == ch) && onOffActive(o.onOff)) {
      //=======================================================================================================
      // if (o.mode == MODE_SUSTAIN) {
      //   digitalWrite(outputPins[i], HIGH);
      // } else {
      //   digitalWrite(outputPins[i], HIGH);
      //   timedActive[i] = true;
      //   outputOffTime[i] = millis() + o.timeMs;
      // }
      //===========================================================================================
      if (o.mode == MODE_SUSTAIN) {

        digitalWrite(outputPins[i], HIGH);

      } else if (o.mode == MODE_TIMED) {

        digitalWrite(outputPins[i], HIGH);

        timedActive[i] = true;
        outputOffTime[i] = millis() + o.timeMs;

      } else if (o.mode == MODE_PULSE) {

        noteHeld[i] = true;
        pulseState[i] = true;

        digitalWrite(outputPins[i], HIGH);

        pulseToggleTime[i] = millis() + o.timeMs;
      }

      //===========================================================================================
    }
  }
}




//===========================================================================
// void noteOff(byte note, byte ch) {
//   for (int i = 0; i < boardOutputs; i++) {
//     auto& o = config.outputs[i];
//     if (o.note == note && (organMode() || o.channel == ch)) {
//       if (o.mode == MODE_SUSTAIN)
//         digitalWrite(outputPins[i], LOW);
//     }
//   }
// }
//==============================================================================
void noteOff(byte note, byte ch) {

  for (int i = 0; i < boardOutputs; i++) {

    auto& o = config.outputs[i];

    if (o.note == note && (organMode() || o.channel == ch)) {

      if (o.mode == MODE_SUSTAIN) {

        digitalWrite(outputPins[i], LOW);

      } else if (o.mode == MODE_PULSE) {

        noteHeld[i] = false;
        pulseState[i] = false;

        digitalWrite(outputPins[i], LOW);
      }
    }
  }
}

//==============================================================================


byte rs = 0, d1 = 0;
bool wait2 = false;

void handleMIDI(byte b) {
  lastMidiActivity = millis();

  if (!midiPlaying) {
    midiPlaying = true;
    showPlaying();
  }

  if (b >= 0xF8) return;

  if ((b & 0x80) && b < 0xF0) {
    rs = b;
    wait2 = false;
    return;
  }

  if (!wait2) {
    d1 = b;
    wait2 = true;
    return;
  }

  byte d2 = b;
  wait2 = false;

  byte ch = (rs & 0x0F) + 1;

  switch (rs & 0xF0) {
    case 0x90:

      if (d2 == 0)
        noteOff(d1, ch);
      else
        noteOn(d1, ch);

      break;

    case 0x80:

      noteOff(d1, ch);
      break;
    case 0xB0:

      if (d1 == 123)  // All Notes Off
        allOutputsOff();

      if (d1 == 120)  // All Sound Off
        allOutputsOff();

      break;
  }
}
//=========================================================================
// void allOutputsOff() {
//   for (int i = 0; i < NUM_OUTPUTS; i++) {
//     digitalWrite(outputPins[i], LOW);
//     timedActive[i] = false;
//   }
// }
//===========================================================================
void allOutputsOff() {

  for (int i = 0; i < NUM_OUTPUTS; i++) {

    digitalWrite(outputPins[i], LOW);

    timedActive[i] = false;

    noteHeld[i] = false;
    pulseState[i] = false;
    pulseToggleTime[i] = 0;
  }
}
//============================================================================
void flashOutput(int outputNum) {
  if (outputNum < 1 || outputNum > NUM_OUTPUTS)
    return;

  int idx = outputNum - 1;
  showTestLine("FLASH OP " + String(outputNum));
  stopFlash = false;

  while (!stopFlash) {
    digitalWrite(outputPins[idx], HIGH);
    delay(250);

    digitalWrite(outputPins[idx], LOW);
    delay(250);

    if (Serial.available()) {
      String cmd = Serial.readStringUntil('\n');
      cmd.trim();

      if (cmd == "STOPFLASH") {
        stopFlash = true;
      }
    }
  }
  lcd.setCursor(0, 3);
  lcd.print("                   ");
  Serial.println("OK");
}
//=======================================================================================
void flashAllOutputs() {
  stopFlash = false;

  //for (int out = 1; out <= NUM_OUTPUTS; out++) {
  for (int out = 1; out <= boardOutputs; out++) {
    showTestLine("FLASH OP " + String(out));
    if (stopFlash) {
      Serial.println("FLASHALL STOPPED");
      return;
    }

    Serial.print("FLASHING OUTPUT ");
    Serial.println(out);

    int idx = out - 1;

    digitalWrite(outputPins[idx], HIGH);
    delay(500);

    digitalWrite(outputPins[idx], LOW);
    //delay(3000);

    for (int t = 0; t < 30; t++) {
      if (Serial.available()) {
        String cmd =
          Serial.readStringUntil('\n');

        cmd.trim();

        if (cmd == "STOPFLASH") {

          lcd.setCursor(0, 3);
          lcd.print("                    ");

          Serial.println("FLASHALL STOPPED");
          return;
        }

        delay(100);
      }
    }
    lcd.setCursor(0, 3);
    lcd.print("                    ");
    Serial.println("FLASHALL COMPLETE");
  }
}
//=================================================================================================
void flashNote(byte note, byte channel) {
  bool found = false;

  for (int i = 0; i < NUM_OUTPUTS; i++) {
    auto& o = config.outputs[i];

    if (o.note == note && o.channel == channel) {
      found = true;

      Serial.print("FLASHING OUTPUT ");
      Serial.print(i + 1);
      Serial.print(" NOTE=");
      Serial.print(note);
      Serial.print(" CH=");
      Serial.println(channel);
      showTestLine("N" + String(note) + " CH" + String(channel) + " OP" + String(i + 1));
      stopFlash = false;

      while (!stopFlash) {
        digitalWrite(outputPins[i], HIGH);
        delay(250);

        digitalWrite(outputPins[i], LOW);
        delay(250);

        if (Serial.available()) {
          String cmd = Serial.readStringUntil('\n');
          cmd.trim();

          if (cmd == "STOPFLASH") {
            stopFlash = true;
            lcd.setCursor(0, 3);
            lcd.print("                    ");
          }
        }
      }
    }
  }

  if (!found) {
    Serial.println("NO MATCH FOUND");
  }
}
//===============================================================================================

void flashNoteOnly(byte note) {
  bool found = false;

  stopFlash = false;

  for (int i = 0; i < NUM_OUTPUTS; i++) {
    if (config.outputs[i].note == note) {
      found = true;

      showTestLine("N" + String(note) + " OP " + String(i + 1));

      Serial.print("FLASHING OUTPUT ");
      Serial.print(i + 1);
      Serial.print(" NOTE=");
      Serial.println(note);
    }
  }

  if (!found) {
    Serial.println("NO MATCHING OUTPUTS");
    return;
  }

  while (!stopFlash) {
    // Turn all matching outputs ON
    for (int i = 0; i < NUM_OUTPUTS; i++) {
      if (config.outputs[i].note == note) {
        digitalWrite(outputPins[i], HIGH);
      }
    }

    delay(250);

    // Turn all matching outputs OFF
    for (int i = 0; i < NUM_OUTPUTS; i++) {
      if (config.outputs[i].note == note) {
        digitalWrite(outputPins[i], LOW);
      }
    }

    delay(250);

    if (Serial.available()) {
      String cmd = Serial.readStringUntil('\n');
      cmd.trim();

      if (cmd == "STOPFLASH") {
        stopFlash = true;
        lcd.setCursor(0, 3);
        lcd.print("                    ");
      }
    }
  }
}
//================================================================================================
void sendConfig() {
  Serial.println(String("VERSION,") + FW_VERSION);
  //Serial.println(String("BOARDTYPE,") + BOARD_TYPE);
  Serial.println(String("BOARDTYPE,") + boardType);
  Serial.println(String("BOARDID,") + config.boardID);
  Serial.println(String("NAME,") + config.boardName);
  Serial.println(String("COMMENT,") + config.comment);
  //for (int i = 0; i < NUM_OUTPUTS; i++) {
  for (int i = 0; i < boardOutputs; i++) {
    auto& o = config.outputs[i];
    Serial.print("OUTPUT,");
    Serial.print(i + 1);
    Serial.print(",");
    Serial.print(o.note);
    Serial.print(",");
    Serial.print(o.channel);
    Serial.print(",");
    Serial.print(o.onOff);
    Serial.print(",");
    Serial.print(o.mode);
    Serial.print(",");
    Serial.println(o.timeMs);
  }
  Serial.println("END");
}
void processCommand(String c) {
  c.trim();
  if (c == "READ") sendConfig();
  else if (c == "SAVE") {
    saveConfig();
    Serial.println("SAVED");
  } else if (c == "VERSION") Serial.println(FW_VERSION);
  else if (c == "FACTORYRESET") {
    loadDefaults();
    saveConfig();
    Serial.println("RESET COMPLETE");
    showIdle();
  } else if (c.startsWith("BOARDID,")) {
    config.boardID = c.substring(8).toInt();
    Serial.println("OK");
  } else if (c.startsWith("NAME,")) {
    String s = c.substring(5);
    s.toCharArray(config.boardName, sizeof(config.boardName));
    Serial.println("OK");
  } else if (c.startsWith("COMMENT,")) {
    String s = c.substring(8);
    s.toCharArray(config.comment, sizeof(config.comment));
    Serial.println("OK");
  } else if (c == "STOPFLASH") {
    stopFlash = true;

    //========================================================================================
  } else if (c.startsWith("FLASHNOTE,")) {
    int note, channel;
    if (sscanf(c.c_str(), "FLASHNOTE,%d,%d",
               &note, &channel)
        == 2) {
      flashNote(note, channel);
    }

    //==============================================================================================================
  } else if (c.startsWith("FLASHNOTEONLY,")) {
    int note;

    if (sscanf(c.c_str(),
               "FLASHNOTEONLY,%d",
               &note)
        == 1) {
      flashNoteOnly(note);
    }
    //}
    //================================================================================================================

  } else if (c.startsWith("FLASH,")) {
    int out = c.substring(6).toInt();
    flashOutput(out);
  } else if (c == "FLASHALL") {
    flashAllOutputs();
  } else if (c.startsWith("SET,")) {
    int out, n, ch, on, m, t;
    if (sscanf(c.c_str(), "SET,%d,%d,%d,%d,%d,%d", &out, &n, &ch, &on, &m, &t) == 6) {
      out--;
      config.outputs[out].note = n;
      config.outputs[out].channel = ch;
      config.outputs[out].onOff = on;
      config.outputs[out].mode = m;
      config.outputs[out].timeMs = t;
      Serial.println("OK");
    }
  }
}
void setup() {
  Serial.begin(115200);
  Serial1.begin(31250);
  lcd.init();
  lcd.backlight();
  pinMode(DIP1_PIN, INPUT_PULLUP);
  pinMode(DIP2_PIN, INPUT_PULLUP);
  detectBoardType();
  loadConfig();
  for (int i = 0; i < NUM_OUTPUTS; i++) {
    pinMode(outputPins[i], OUTPUT);
    digitalWrite(outputPins[i], LOW);
    timedActive[i] = false;
  }
  for (int i = 0; i < NUM_ONOFF; i++) {
    pinMode(onOffPins[i], INPUT_PULLUP);
  }

  for (int pin = A0; pin <= A13; pin++) {  // CHANGED A15 TO A13 TO MATCH OUTPUTS ON BOARD
    pinMode(pin, INPUT_PULLUP);
    pinMode(ORGAN_MODE_PIN, INPUT_PULLUP);
  }
  showIdle();
}
void loop() {
  while (Serial.available()) {
    String incoming =
      Serial.readStringUntil('\n');
    int start = 0;
    while (start < incoming.length()) {
      int endPos =
        incoming.indexOf(';', start);
      if (endPos == -1)
        endPos = incoming.length();
      String cmd =
        incoming.substring(start, endPos);
      cmd.trim();
      if (cmd.length() > 0)
        processCommand(cmd);
      start = endPos + 1;
    }
  }
  while (Serial1.available())
    handleMIDI(Serial1.read());
  for (int i = 0; i < NUM_OUTPUTS; i++) {
    if (timedActive[i] && millis() >= outputOffTime[i]) {
      digitalWrite(outputPins[i], LOW);
      timedActive[i] = false;
    }
  }
  for (int i = 0; i < boardOutputs; i++) {

    auto& o = config.outputs[i];

    if (o.mode == MODE_PULSE && noteHeld[i] && millis() >= pulseToggleTime[i]) {

      pulseState[i] = !pulseState[i];

      digitalWrite(outputPins[i],
                   pulseState[i] ? HIGH : LOW);

      pulseToggleTime[i] = millis() + o.timeMs;
    }
  }
  bool currentOrganMode = organMode();
  if (currentOrganMode != lastOrganMode) {
    lastOrganMode = currentOrganMode;
    showIdle();
  }
  if (midiPlaying && millis() - lastMidiActivity > 2000) {
    midiPlaying = false;
    showIdle();
  }
  if (lcdReturnTime && millis() > lcdReturnTime) {
    lcdReturnTime = 0;
    showIdle();
  }
}
